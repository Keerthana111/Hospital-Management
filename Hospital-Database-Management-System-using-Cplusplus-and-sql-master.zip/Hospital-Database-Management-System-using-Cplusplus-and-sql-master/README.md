# Hospital-Database-Management-System-using-c++-and-sql

Hello guys,
          My name is Jophin Joseph N. I stay in Bangalore but I'm basically from Kerala. I did my Engineering in Computer Science from Sir M. Visvesvaraya Institute of Technology, Bangalore. I have basic knowledge about programming concepts and languages like C, C++, Java, Python, HTML, CSS, PHP, Android studio etc. My hobbies are watching movies, reading books, playing badminton etc. This project is a simple Hospital Management system developed using devc++, codeblocks and XAMP(Mysql) server. It makes use of a database to store all the doctor and patient details.
          
 Thank You!!!!         
